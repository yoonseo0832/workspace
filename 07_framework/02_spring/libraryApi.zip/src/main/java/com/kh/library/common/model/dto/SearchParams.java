package com.kh.library.common.model.dto;

import lombok.Data;

@Data
public class SearchParams {
	
	private String filter;
	private String keyword;

}
